<?php

require("phpMQTT.php");
require("config.php");

if(isset($_POST['msg']) && isset($_POST['Publish']))
{
  $message = $_POST['msg'];

  //MQTT client id to use for the device. "" will generate a client id automatically

  $mqtt = new bluerhinos\phpMQTT($host, $port, "ClientID".rand());
  if ($mqtt->connect(true,NULL,$username,$password)) 
  {
    $mqtt->publish("phpmqtt",$message, 0);
    $mqtt->close();
  }
  else
  {
    echo "Fail or time out";
  }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- CSS only -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
  <title>MQTT: php</title>
</head>
<body>
  <div class="container rounded w-50 h-50  mt-5 p-3 bg-warning">
  <form method="POST" class="row content-center">
    <div class="rounded  alert-primary h-75 col-4">
     topic : Testing1 
    </div>
    <div class="form-group col-6">
      <input type="text" name="msg" class="form-control"/>
    </div>
    <div class="form-group col-2">
      <input type="submit" name="Publish" value="Publish" class="btn btn-primary"/>
    </div>
  </form>
  </div>
  
</body>
</html>