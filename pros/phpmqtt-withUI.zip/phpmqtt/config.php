<?php

$host   = "broker.emqx.io"; 
$port     = "1883";
$username = "";
$password = "";

?>