<?php
ini_set ( 'max_execution_time' , '20' );
require("phpMQTT.php");
require("config.php");
$mqtt = new bluerhinos\phpMQTT($host, $port, "ClientID".rand());

if(!$mqtt->connect(true,NULL,$username,$password))
{
  exit(1);
}

//currently subscribed topics
$topics['phpmqtt'] = array("qos"=>0, "function"=>"procmsg");
$mqtt->subscribe($topics,0);

while($mqtt->proc())
{
  echo "";
}

$mqtt->close();
function procmsg($topic,$msg)
{
  echo "Msg Recieved: $msg"."<br/>";
}

?>