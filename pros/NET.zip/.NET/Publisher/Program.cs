﻿using MQTTnet;
using MQTTnet.Client;
using MQTTnet.Client.Options;
using System;
using System.Threading.Tasks;

namespace Publisher
{
    class Program
    {
        static async Task Main(string[] args)
        {
            int i = 0;
            do
            {
                var mqttfactory = new MqttFactory();
                var client = mqttfactory.CreateMqttClient();
                var options = new MqttClientOptionsBuilder().WithClientId(Guid.NewGuid().ToString())
                .WithTcpServer("broker.emqx.io", 1883)
                .WithCleanSession()
                .Build();

                client.UseConnectedHandler(e =>
                {
                    Console.WriteLine("Connected To Mqtt");
                });

                client.UseDisconnectedHandler(e =>
                {
                    //Console.WriteLine("DisConnected To Mqtt");
                });
                await client.ConnectAsync(options);

                await PublishMessageAsync(client);
                await client.DisconnectAsync();
                Console.WriteLine("Enter 0 to continue ::");
                Console.ReadLine();
            } while (i == 0);
        }
        private static async Task PublishMessageAsync(IMqttClient client)
        {
            Console.WriteLine("Enter Message Payload ::");
            string messagePayload = Console.ReadLine();
            var message = new MqttApplicationMessageBuilder().WithTopic("Testing_25").WithPayload(messagePayload).WithAtLeastOnceQoS().Build();

            if (client.IsConnected)
            {
                await client.PublishAsync(message);
            }

        }

    }
}

